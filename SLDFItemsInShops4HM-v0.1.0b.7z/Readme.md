Adds Heavy Metal upgrades to SLDFItemsInShops

## Required Mods:
- ModTek v0.7.7.2 or later: https://github.com/BattletechModders/ModTek
- SLDFItemsInShops v0.5.0 or later:
https://github.com/shaygover/BTshopsupgrade
